create database final;
use final;
select * from bank_account_details;
select*from bank_account_transaction;
Select
Bd.Account_Number,Balance_amount, Transaction_amount,
Transaction_Date
from Bank_Account_Details Bd
inner join
bank_account_transaction Bt
on Bd.account_number = Bt.account_number
And ( Transaction_Date between "2020-03-01" and
"2020-04-30");


#7.Highest purch_amt from Orders table.
select*from orders;
select purch_amt from orders
order by purch_amt desc 
limit 1 offset 4;

#12.Inserting five rows 

select * from cast;
INSERT INTO cast (mov_id, role, act_id)
VALUES (936, 'Darth Vader', 126),
       (939, 'Sarah Connor', 140),
       (942, 'Ethan Hunt', 135),
       (930, 'Travis Bickle', 131),
       (941, 'Antoine Doinel', 144);
select*from cast;
       
